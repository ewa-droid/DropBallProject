package model;

public enum CupSkin 
{
    RED,
    YELLOW,
    GREEN,
    BLUE
}
