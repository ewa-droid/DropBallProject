package model;

public enum BallSkin 
{
    RED,         
    YELLOW,
    GREEN,
    BLUE
}