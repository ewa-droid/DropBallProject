package view;

import javafx.animation.AnimationTimer;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import mainController.GameController;
import model.Ball;
import model.Cup;
import model.Level;
import model.Obstacle;
import model.Path;

import java.util.ArrayList;
import java.util.List;

public class LevelView 
{
    private static final int WINDOW_WIDTH = 1000;
    private static final int WINDOW_HEIGHT = 800;

    private final GameController gameController;

    private AnimationTimer gameLoop;
    private Pane gameArea;
    private Ball ball;
    private Cup cup;
    private List<Path> paths = new ArrayList<>();
    private Level currentLevel;
    private boolean isDrawing;
    private boolean gameOver;
    private Text levelText;

    private StackPane layeredRoot;

    public LevelView(GameController gameController) 
    {
        this.gameController = gameController;
    }

    public Scene createScene(Level level) 
    {
        this.currentLevel = level;
        this.gameOver = false;

        layeredRoot = new StackPane();

        BorderPane root = new BorderPane();

        gameArea = new Pane();
        gameArea.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        gameArea.setStyle("-fx-background-color: #f0f0f0;");

        initializeGameElements();

        root.setCenter(gameArea);
        HBox topControls = createTopControls();
        root.setTop(topControls);

        layeredRoot.getChildren().add(root);

        setupMouseHandlers();
        startGameLoop();

        Scene scene = new Scene(layeredRoot, WINDOW_WIDTH, WINDOW_HEIGHT);

        scene.setOnKeyPressed(event -> 
        {
            if (event.getCode() == KeyCode.SPACE) 
            {
            	if (ball.isInCup(cup))
            		gameController.startLevel(level.getLevelNumber());
            	else
            		gameController.restartLevel();
            }
            
            else if (event.getCode() == KeyCode.ESCAPE) 
            {
                gameController.showLevelSelection();
            }
        });

        gameArea.requestFocus();

        return scene;
    }

    private void initializeGameElements() 
    {
        gameArea.getChildren().clear();
        paths.clear();

        ball = new Ball
        (
        	currentLevel.getBallStartX(), 
        	currentLevel.getBallStartY(), 
        	gameController.getSelectedBallSkin()
        );
        
        cup = new Cup
        (
            currentLevel.getCupX(),
            currentLevel.getCupY(),
            gameController.getSelectedCupSkin()
        );
        
        gameArea.getChildren().add(cup.getShape());
        gameArea.getChildren().add(ball.getShape());

        for (Obstacle obstacle : currentLevel.getObstacles()) 
        {
            gameArea.getChildren().add(obstacle.getShape());
        }
    }

    private HBox createTopControls() 
    {
        HBox controls = new HBox(20);
        controls.setPadding(new Insets(10));
        controls.setAlignment(Pos.CENTER);
        controls.setStyle("-fx-background-color: #cccccc;");

        Button menuButton = new Button("Menu");
        menuButton.setFont(Font.font("Arial", FontWeight.BOLD, 21));
        menuButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
        menuButton.setOnAction(e -> gameController.showLevelSelection());

        Button resetButton = new Button("Reset");
        resetButton.setFont(Font.font("Arial", FontWeight.BOLD, 21));
        resetButton.setStyle("-fx-background-color: #ff9800; -fx-text-fill: white;");
        resetButton.setOnAction(e -> gameController.restartLevel());

        levelText = new Text("Poziom " + currentLevel.getLevelNumber());
        levelText.setFont(Font.font("Arial", FontWeight.BOLD, 30));
        levelText.setFill(Color.DARKBLUE);

        Region spacerLeft = new Region();
        Region spacerRight = new Region();
        HBox.setHgrow(spacerLeft, Priority.ALWAYS);
        HBox.setHgrow(spacerRight, Priority.ALWAYS);

        controls.getChildren().addAll(menuButton, spacerLeft, levelText, spacerRight, resetButton);
        return controls;
    }

    private void setupMouseHandlers() 
    {
        gameArea.setOnMousePressed(e -> 
        {
            if (!gameOver) 
            {
            	 double dx = e.getX() - ball.getX();
                 double dy = e.getY() - ball.getY();
                 double distance = Math.sqrt(dx * dx + dy * dy);
                 
                 //	Warunek na rysowanie gdy kursor najedzie na piłeczkę
                 if (distance <= ball.getRadius()) 
                 {
                     return;
                 }
            	
            	isDrawing = true;
                Path newPath = new Path();
                paths.add(newPath);
                Line line = newPath.addPoint(e.getX(), e.getY());
                if (line != null) 
                {
                    gameArea.getChildren().add(line);
                }
            }
        });

        gameArea.setOnMouseDragged(e -> 
        {
            if (isDrawing && !paths.isEmpty()) 
            {
            	double dx = e.getX() - ball.getX();
                double dy = e.getY() - ball.getY();
                double distance = Math.sqrt(dx * dx + dy * dy);
                
                // Warunek na rysowanie gdy kursor najedzie na piłeczkę
                if (distance <= ball.getRadius()) 
                {
                    return;
                }
            	
            	Path currentPath = paths.get(paths.size() - 1);
                Line line = currentPath.addPoint(e.getX(), e.getY());
                if (line != null) 
                {
                    gameArea.getChildren().add(line);
                }
            }
        });

        gameArea.setOnMouseReleased(e -> 
        {
            isDrawing = false;
            if (!ball.isMoving()) 
            {
                // Nadawanie prędkości początkowej piłeczce
            	ball.setInitialVelocity(0, 0.5);
            }
        });
    }

    private void startGameLoop() 
    {
        if (gameLoop != null) 
        {
            gameLoop.stop();
        }

        gameLoop = new AnimationTimer() 
        {
            @Override
            public void handle(long now) 
            {
                updateGame();
            }
        };

        gameLoop.start();
    }

    public void cleanup() 
    {
        if (gameLoop != null) 
        {
            gameLoop.stop();
        }
    }

    private void updateGame() 
    {
        if (gameOver) return;

        if (ball.isMoving()) 
        {
            ball.update();
            ball.handleWallCollision(0, gameArea.getWidth(), 0, gameArea.getHeight());

            for (Path p : paths) 
            {
                p.checkCollisionWithBall(ball);
            }

            for (Obstacle obstacle : currentLevel.getObstacles()) 
            {
                obstacle.checkCollision(ball);
            }

            if (ball.isInCup(cup)) 
            {
                gameOver = true;
                ball.stop();
                gameController.levelCompleted();
                showLevelCompletedOverlay();
            }

            Point2D velocity = ball.getVelocity();
            if (Math.abs(velocity.getX()) < 0.01 && Math.abs(velocity.getY()) < 0.01) {
                if (ball.getY() > WINDOW_HEIGHT - 20) 
                {
                    ball.stop();
                }
            }
        }
    }

    private void showLevelCompletedOverlay() 
    {
        LevelCompletedOverlay overlay = new LevelCompletedOverlay(gameController, currentLevel.getLevelNumber());
        layeredRoot.getChildren().add(overlay);
    }
}